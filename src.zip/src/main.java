import Exceptions.*;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String cpf = "13384332458";
		Cliente jose = new Cliente(cpf,"Jos� Bezerra", 18, "Angus Bacon");
		Cliente joseNovo = new Cliente(cpf,"Jos� Bezerra de Melo", 18, "Angus Bacon");
		
		Funcionario andre = new Funcionario("13384332451", "Andre Vasc", 19, 9442224, "Gerente", "R. Jos� Alvaro de Melo", "Solteiro", "NENHUM");
		Funcionario andreNovo = new Funcionario("13384332451", "Andre Vasconcelos", 19, 9442224, "Gerente", "R. Jos� Alvaro de Melo", "Solteiro", "NENHUM");
		
		NegociosPessoas neg = new NegociosPessoas(0);
		
		try {
			neg.inserir(jose);
			System.out.println("[Cliente] Inserir OK");
			
			neg.procurarCliente(cpf);
			System.out.println("[Cliente] Procurar OK");
			
			neg.atualizar(joseNovo);
			System.out.println("[Cliente] Atualizar OK");
			
			neg.removerCliente(cpf);
			System.out.println("[Cliente] Remover OK");	
			
			System.out.println("");
			
			neg.inserir(andre);
			System.out.println("[Funcionario] Inserir OK");

			neg.procurarFuncionario("13384332451");
			System.out.println("[Funcionario] Procurar OK");
			
			neg.atualizar(andreNovo);
			System.out.println("[Funcionario] Atualizar OK");
			
			neg.removerFuncionario("13384332451");
			System.out.println("[Funcionario] Remover OK");	
			
		} catch (PessoaJaCadastradaException | CPFInvalidoException| PessoaNaoCadastradaExeception | GerenteJaExistenteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
