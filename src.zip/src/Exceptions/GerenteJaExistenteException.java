package Exceptions;

public class GerenteJaExistenteException extends Exception{
	public GerenteJaExistenteException() {
		super("Gerente ja existente!");
	}
}
